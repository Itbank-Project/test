package com.itbank.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.itbank.member.MemberDTO;
import com.itbank.service.MemberService;

@Controller
public class MemberController {

	@Autowired MemberService ms;
	
	@GetMapping("login")
	public void login() {}
	
	@PostMapping("login")
	public String login(MemberDTO dto, HttpServletRequest request,HttpServletResponse response, HttpSession session) {
		String userid = dto.getUserid();
		String storeid = request.getParameter("storeid");
		System.out.println(userid);
		System.out.println(storeid);
		
		MemberDTO login = ms.getMember(dto);
		
		Cookie c = 	new Cookie("userid", userid);
				
		session.setAttribute("login",login);
		String viewName = login != null ? "redirect:/" : "redirect:javascript:history.go(-1)";
		
				
		boolean flag = (storeid != null) && (session.getAttribute("login") != null);
		
		c.setMaxAge(flag ? 60 * 60 * 24 * 100 : 0);	
		response.addCookie(c);	
		
		return viewName;
	
	}
	
	@GetMapping("logout")
	public String logout(HttpSession session) {
		session.removeAttribute("login");
		return "redirect:/";
	}
	
	
}
