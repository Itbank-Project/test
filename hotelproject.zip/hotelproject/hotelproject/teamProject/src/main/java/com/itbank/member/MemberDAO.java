package com.itbank.member;

import java.util.HashMap;
import java.util.List;

public interface MemberDAO {

	MemberDTO selectMember(MemberDTO dto);

	int updateMember(HashMap<String, String> param);


}
