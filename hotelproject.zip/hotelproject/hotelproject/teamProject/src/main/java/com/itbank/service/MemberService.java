package com.itbank.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itbank.member.Hash;
import com.itbank.member.MemberDAO;
import com.itbank.member.MemberDTO;

@Service
public class MemberService {

	@Autowired private MemberDAO dao;
	
	public MemberDTO getMember(MemberDTO dto) {
		
		dto.setUserpw(Hash.getHash(dto.getUserpw()));
		
		return dao.selectMember(dto);
	}

	public int updateMember(HashMap<String, String> param) {
		String newUserpw, newUserpw2;
		newUserpw = param.get("newUserpw");
		newUserpw2 = param.get("newUserpw2");
		if(newUserpw.equals(newUserpw2)) {
			param.put("userpw", Hash.getHash(param.get("userpw")));
			param.put("newUserpw", Hash.getHash(param.get("newUserpw")));
			return dao.updateMember(param);
		}
		return -1;
	}

	public MemberDTO getMember(String userid, String userpw) {
		MemberDTO dto = new MemberDTO();	// 비어있는 객체를 생성하고
		dto.setUserid(userid);				// 전달받은 값을 객체에 넣어준 다음에
		dto.setUserpw(userpw);				
		return getMember(dto);				// 기존에 만들어진 메서드를 호출하여 그대로 작업한다
	}



}
