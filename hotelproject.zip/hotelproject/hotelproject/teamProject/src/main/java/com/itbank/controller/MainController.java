package com.itbank.controller;

import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.itbank.member.MemberDTO;
import com.itbank.service.MemberService;

@Controller
public class MainController {

	@Autowired MemberService ms;
	
	@RequestMapping("")
	public String index() {
		return "index";
	}

	@PostMapping("")
	public ModelAndView updateMember(@RequestParam HashMap<String, String> param, HttpSession session) {
		System.out.println("map : " + param.get("userid"));
		ModelAndView mav = new ModelAndView("msg");
		int row = ms.updateMember(param);
		switch(row) {
		case 1:	
			mav.addObject("msg", "정보 수정 성공 !!");
			mav.addObject("page", "/");
			MemberDTO login = ms.getMember(param.get("userid"), param.get("newUserpw"));
			session.setAttribute("login", login);
			break;
		case -1:
			mav.addObject("msg", "신규 비밀번호가 일치하지 않습니다");
			break;
		case 0:
			mav.addObject("msg", "정보 수정 실패 !! 다시 확인해 주세요");
			break;
		}
		return mav;
	}

	@RequestMapping("salesRecord")
	public String salesRecord() {
		return "salesRecord";
	}

	@RequestMapping("roomStatus")
	public String roomStatus() {
		return "roomStatus";
	}

	@RequestMapping("calculate")
	public String calculate() {
		return "calculate";
	}

	@RequestMapping("hotelInformation")
	public String hotelInformation() {
		return "hotelInformation";
	}
	
	// 컨트롤러 레벨에서 발생하는 예외를 종류별로 모아서 별도의 메서드로 처리하는 형태
	@ExceptionHandler(EmptyResultDataAccessException.class)
	public ModelAndView loginFail(EmptyResultDataAccessException e) {
		ModelAndView mav = new ModelAndView("msg");
//		System.out.println(e);
//		e.printStackTrace();
		mav.addObject("msg", "일치하는 계정 혹은 패스워드를 찾을 수 없습니다");
		mav.addObject("page", "/login/");
		return mav;
	}

}
