package com.itbank.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class LoginInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		System.out.println(handler);
		
		
		HttpSession session = request.getSession(false); 	
		if(session != null && session.getAttribute("login") != null) {
			System.out.println("preHandle : true");
			return true;
		}
		String requestURI = request.getRequestURI(); 	
		System.out.println("requestURI : " + requestURI);
		requestURI = requestURI.substring(request.getContextPath().length());
		
		System.out.println("preHandle : false");

		
		response.sendRedirect(request.getContextPath() + "/login?uri=" + requestURI);	

		return false;	
	}
	
}
