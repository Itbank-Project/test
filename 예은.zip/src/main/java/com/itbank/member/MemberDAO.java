package com.itbank.member;

public interface MemberDAO {

	MemberDTO selectOne(MemberDTO dto);

	String selectPassword(String userpw);

	int updatePassword(String newPw1);
	

}
