package com.itbank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.itbank.member.MemberDTO;
import com.itbank.service.MemberService;

@RestController
public class AjaxController {

	@Autowired private MemberService ms;
	
	// 현재 비밀번호와 일치하는지 확인
	@PostMapping(value = "checkPw", produces = "application/json;charset=utf8")
	public String pwCheck (String userpw) {
		System.out.println(userpw);
		boolean check = ms.selectPW(userpw);
		return check ? "신규 비밀번호를 입력하세요." : "비밀번호를 잘못입력하였습니다.";
	}
	
	// 비밀번호 변경
	@PutMapping(value = "changePW/{newPw1:.+}", consumes = "application/json;charset=utf8")
	public int changePw(@PathVariable String newPw1) {
		System.out.println(newPw1);
		int row = ms.updatePw(newPw1);
		System.out.println(row);
		return row;
	}
}
