package com.itbank.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.itbank.member.MemberDTO;
import com.itbank.service.MemberService;

@Controller
public class MainController {

	@Autowired private MemberService ms;
	
	@RequestMapping("")
	public String index() {
		return "index";
	}
	
	// 로그인
	@GetMapping("login")
	public void login() {}


	@PostMapping("login")
	public ModelAndView login(MemberDTO dto, HttpSession session) {
		MemberDTO login = ms.getUser(dto);
		session.setAttribute("login", login);
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName(login != null ? "index" : "msg");
		if(login == null) {
			mav.addObject("msg", "아이디 혹은 비밀번호를 잘못입력하였습니다.");
		}
		return mav;
	}
	
	@GetMapping("logout")
	public String logout(HttpSession session) {
		session.removeAttribute("login");
		return "redirect:/";
	}
	
	// 정산페이지
	@GetMapping("calculate")
	public void calculate() {}
	
}
