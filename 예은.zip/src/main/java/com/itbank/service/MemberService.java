package com.itbank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itbank.member.Hash;
import com.itbank.member.MemberDAO;
import com.itbank.member.MemberDTO;

@Service
public class MemberService {

	@Autowired private MemberDAO dao;

	public MemberDTO getUser(MemberDTO dto) {
		dto.setUserpw(Hash.getHash(dto.getUserpw()));
		return dao.selectOne(dto);
	}

	public boolean selectPW(String userpw) {
		userpw = Hash.getHash(userpw);
		String dbpw = dao.selectPassword(userpw);
		return dbpw != null;
	}

	public int updatePw(String newPw1) {
		newPw1 = Hash.getHash(newPw1);
		return dao.updatePassword(newPw1);
	}
}
