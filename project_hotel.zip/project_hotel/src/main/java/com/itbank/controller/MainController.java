package com.itbank.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {

	
	@RequestMapping("")
	private String index() {
		return "index";
	}
	
	@GetMapping("salesRecord")		// 판매 기록
	private void salesRecord() {}
	
	@GetMapping("room")				// 객실 현황
	private void room() {}
	
	@GetMapping("calculate")		// 정산
	private void calculate() {}
}
